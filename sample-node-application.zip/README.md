# MEAN Stack Application
Basic Node Framework

This project shall serve you as a starting point for MEAN application.

User shall continue building his architecture on the initial framework already created.

Application contains the basic framework to Integarete Following features in the Node Project

  1. MongoDb: To Integrate With the Database
  2. Vash View Engine: To Integrate View Engine
  3. Express: To Define Routing
  4. Bower: To Load Client Side Modules
  5. Grunt: To Load server Modules
  6. Angular: To Integrate Client Side Angular Library
  7. Require.js: Used to manage dependency on the client side

".gitignore" file is ussually made to ignore the changes made to files/folder specified inside the File.

Here we can ignore those files and folder which is not needed to be committed on GitHub Server
